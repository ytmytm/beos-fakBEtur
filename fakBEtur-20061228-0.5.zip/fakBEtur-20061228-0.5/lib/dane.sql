INSERT INTO firma VALUES(1,'YTM Enterprises','YTM','ul. Słowackiego 0/0','77-400','Złotów','067 265 13 18','ytm@elysium.pl','111-11-111','222-22-222','mBank','60 1140 2004 0000 3234 3268',1,1,1,0);
INSERT INTO firma VALUES(2,'Danex sp. z o.o.','DANEX','ul. Naramowicka 6/57','61-616','Poznań','058 616161','danex@danex.com.pl','','','','',0,0,1,1);

INSERT INTO faktura VALUES(1,'01/11/2005','2005-11-25','Złotów','2005-11-25','2005-12-25','przelewem','własny odbiorcy','Witkowiak',NULL,1,'2005-12-12',123,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO faktura VALUES(2,'02/11/2005','2005-11-25','Jastrowie','2005-11-25','2005-12-25','gotówką','fura','Kociewiak',NULL,1,'2005-12-25',20,'YTM Enterprises','ul. Słowackiego 6/57','77-400','Złotów','067 265 13 18','ytm@elysium.pl','111-11-111','222-22-222','mBank','60 1140 2004 0000 3234 3268');

INSERT INTO towar VALUES(1,'Mleko 3%','UHT3','11.11.11','l',0,'2005-11-24',5,3.11,3.05,5.00,3.00,1.00,0.00,'mleko UHT 3%, palety');
INSERT INTO towar VALUES(2,'Mleko 5%','UHT5','11.11.11','l',0,'2005-11-24',2,2.63,2.50,5.00,0.00,1.00,0.00,'');

